# Campus-Event-Reporting
Campus Event System A simple website for schools and colleges to manage events. Students can browse events, register, and give feedback, while teachers can create events, track attendance, and view reports. Built with Node.js, MySQL, and vanilla JavaScript. Easy to set up and use.
