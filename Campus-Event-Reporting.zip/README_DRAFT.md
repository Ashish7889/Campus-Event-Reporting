my school event website

i made a website for my College
students can see fun events and join them
teachers can make new events

what it does

students can:
see events
join events
say if they liked it

teachers can:
make events
see who joined
check who came

how to run it

1. put files on computer
2. open black window
3. type npm install
4. fix password in env file
5. type npm start
6. go to localhost:4000

how to use

students click events to see them
students click register to join
students click feedback to rate

teachers click admin
password is admin123456
then make events

what i used

node js
mysql
html and css
